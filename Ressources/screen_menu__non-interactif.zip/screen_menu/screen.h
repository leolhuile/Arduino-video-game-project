#ifndef __SCREEN__

  // UTFT library : (GLCD screen)
  #include <UTFT.h>
  #include <avr/pgmspace.h>

  UTFT screen(SSD1289, 38, 39, 40, 41); //<-- parameters are already adjusted to Schield model

  #define x_RECT1 95
  #define y_RECT1 110

  #define x_RECT2 95
  #define y_RECT2 160

  void menuSetup() {
    screen.InitLCD(LANDSCAPE);

    //Switch ON screen :
    screen.fillScr(VGA_WHITE);

    //Draw Rect
    screen.setColor(VGA_BLACK);
    //drawRoundRect(x1,y1 , x2,y2)
    screen.drawRoundRect(
      //1st corner
      x_RECT1,
      y_RECT1,
      //2nd corner 
      x_RECT1 + 135,
      y_RECT1 + 30
    );
    screen.drawRoundRect(
      //1st corner
      x_RECT2,
      y_RECT2,
      //2nd corner 
      x_RECT2 + 135,
      y_RECT2 + 30
    );

    //Print games' names on screen :
    screen.setFont ("Arial");
    //TODO : print(str , x,y , optional<degrees>)
    screen.print(
      "Snake",
      x_RECT1 + 77,
      y_RECT1 + 15
    );
    screen.print(
      "Pong",
      x_RECT2 + 77,
      y_RECT2 + 15
    );
  }

  #define __SCREEN__
#endif