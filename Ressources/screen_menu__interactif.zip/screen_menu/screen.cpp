#include "screen.h"

extern uint8_t SmallFont[];
extern uint8_t BigFont[];

void menu_setup() {
  screen.InitLCD(LANDSCAPE);

  //Switch ON screen :
  screen.fillScr(RGB_BLACK);

  //Draw Menu Rect :
  menu_Snake_drawBox(RGB_WHITE);
  menu_Pong_drawBox(RGB_WHITE)

  //Print Title :
  screen.setBackColor(RGB_BLACK);
  screen.setColor(220,180,150);  //<-- Title Color
  screen.setFont(BigFont);
  screen.print("Penta BOX", CENTER, 0);
}

void menu_Snake_drawBox(uint_t r, uint_t g, uint_t b) {
  screen.setColor(r,g,b);

  const int Y_RECT = 110;

  //Draw Rect :
  screen.drawRoundRect(       //param : (x1,y1 , x2,y2)
    //1st corner
    90 , Y_RECT,
    //2nd corner 
    90 + 135, Y_RECT + 30
  );

  //Print games' names on screen :
  screen.setBackColor(RGB_BLACK);
  screen.setFont(SmallFont);
  screen.print(               //param : (string , x,y , optional<degrees>)
    "Snake",
    CENTER,
    Y_RECT + 15
  );
}
void menu_Pong_drawBox(uint_t r, uint_t g, uint_t b) {
  screen.setColor(r,g,b);

  const int Y_RECT = 160;

  //Draw Rect :
  screen.drawRoundRect(       //param : (x1,y1 , x2,y2)
    //1st corner
    90 , Y_RECT,
    //2nd corner 
    90+135 , Y_RECT + 30
  );

  //Print games' names on screen :
  screen.setBackColor(RGB_BLACK);
  screen.setFont(SmallFont);
  screen.print(               //param : (string , x,y , optional<degrees>)
    "Pong",
    CENTER,
    Y_RECT + 15
  );
}