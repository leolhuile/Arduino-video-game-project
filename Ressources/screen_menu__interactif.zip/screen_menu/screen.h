#ifndef __SCREEN__

  #define uint_t unsigned int

  // UTFT library : (GLCD screen)
  #include <UTFT.h>
  UTFT screen(SSD1289, 38, 39, 40, 41); //<-- parameters are already adjusted to Schield model

  #define RGB_WHITE 255, 255, 255
  #define RGB_BLACK 0, 0, 0
  // Chosen Box Color :
  #define RGB_GREEN 0, 255, 0

  void menu_setup();

  void menu_Snake_drawBox(uint r, uint g, uint b);
  void menu_Pong_drawBox(uint r, uint g, uint b);

  #define __SCREEN__
#endif