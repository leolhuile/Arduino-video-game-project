#ifndef __GLOBAL_VARS__

  // States :
  enum class MainState { Menu, Snake, Pong };
  extern MainState main_state;

  enum class GameState { Loading, Paused, Playing };
  extern GameState game_state;

  // To declare it ONCE and for all :
  extern char b_message;

  #define __GLOBAL_VARS__
#endif