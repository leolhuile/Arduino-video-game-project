#ifndef __MENU__
  #include "screen.h"
  #include "global_vars.h"

  void menu_setup();
  void menu_loop();

  #define __MENU__
#endif