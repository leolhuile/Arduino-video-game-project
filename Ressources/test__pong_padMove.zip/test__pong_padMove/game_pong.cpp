#include "games.h"


// ----------------------------------- TOOLS -----------------------------------


/*namespace {
  //static const int BORDER_WIDTH = 5;

  inline static void drawField() { //TODO : Patch
    d_setColor(RGB_GRAY);
    
    // Borders :
    screen.fillRect(
      0, 0,
      SCREEN_WIDTH, 25
    );
    screen.fillRect(
      0, SCREEN_HEIGHT-25,
      SCREEN_WIDTH, SCREEN_HEIGHT
    );
  }
}*/


// TODO : Removing those macros :
#define PAD_COLOUR RGB_WHITE   // TODO : Choisir une couleur pour les pads
#define BALL_COLOUR RGB_GREEN  // TODO : Choisir une couleur pour la balle


/*************** PAD ***************/
namespace {
  class Pad {
    //# ¤¤¤¤¤¤¤¤¤¤ CLASS ATTRIBUTS ¤¤¤¤¤¤¤¤¤ #//
    //Measures :
    pub static const int PAD_LENGTH;
    pub static const int PAD_WIDTH;
    //Limits :
    pub static const int TOP_LIMIT;
    pub static const int BOTTOM_LIMIT;


    //# ¤¤¤¤¤¤¤¤¤¤¤¤¤ ATTRIBUTS ¤¤¤¤¤¤¤¤¤¤¤¤ #//
    priv const int x;
    priv       int y; // Top of the pad  NOT  its Center


    //# ¤¤¤¤ CONSTRUCTORS & DESTRUCTORS ¤¤¤¤ #//
    priv Pad(int x, int y): x(x), y(y) {}

    pub static inline Pad createPlayer() {
      return Pad(
        0 + 1,
        Y_MID - PAD_LENGTH / 2
      );
    }

    pub static inline Pad createComputer() {
      return Pad(
        SCREEN_WIDTH - PAD_WIDTH - 1,
        Y_MID - PAD_LENGTH / 2
      );
    }


    //# ¤¤¤¤¤¤¤¤¤ GETTERS & SETTERS ¤¤¤¤¤¤¤¤ #//
    pub int getYTop()
    const noexcept {
      return self.y;
    }

    pub int getYCenter()
    const noexcept {
      return self.y + PAD_LENGTH / 2;
    }


    //# ¤¤¤¤¤¤¤¤¤¤¤¤¤¤ METHODS ¤¤¤¤¤¤¤¤¤¤¤¤¤ #//

    /* Draw pad at current coordinates : (self.x , self.y) */
    priv inline void drawPad(uint8_t r, uint8_t g, uint8_t b)
    const noexcept {
      d_setColor(r,g,b);
      screen.fillRect(
        self.x, self.y,
        self.x + PAD_WIDTH, self.y + PAD_LENGTH
      );
    }
    /* Erase pad with black rect */
    priv inline void erasePad()
    const noexcept {
      drawPad(RGB_BLACK);
    }

    // -------------- DEBUG ------------- //
    pub inline void debug_drawPad(uint8_t r, uint8_t g, uint8_t b)
    const noexcept {
      self.erasePad();

      Serial.println("In draw");
      Serial.print("x : "); Serial.println(self.x);
      Serial.print("y : "); Serial.println(self.y);

      // Draw pad :
      self.drawPad(r,g,b);
    }

    // -------------- SETUP ------------- //
    //TODO : Making method to draw pads on screen at setup :
    // ...


    // ------------- PLAYING ------------ //
    pub inline void moveUp(int speed)
    noexcept {
      if (self.y == TOP_LIMIT) return;

      self.erasePad();
      self.y -= (speed <= self.y) ? speed : self.y;
      self.drawPad(PAD_COLOUR);
    }
    pub inline void moveDown(int speed)
    noexcept {
      if (self.y == BOTTOM_LIMIT) return;

      self.erasePad();
      const int dy = BOTTOM_LIMIT - self.y;
      self.y += (speed <= dy) ? speed : dy;
      self.drawPad(PAD_COLOUR);
    }
  };
  const int Pad::PAD_LENGTH   = 35;
  const int Pad::PAD_WIDTH    = 5;
  const int Pad::TOP_LIMIT    = 0;
  const int Pad::BOTTOM_LIMIT = 205; // <-- SCREEN_HEIGHT - PAD_LENGTH


  static Pad player   = Pad::createPlayer();
  static Pad computer = Pad::createComputer();
}


/*************** BALL **************/
namespace {
  class Ball {
    enum class Direc { Right = 1, Left = -1 };

    //# ¤¤¤¤¤¤¤¤¤¤ CLASS ATTRIBUTS ¤¤¤¤¤¤¤¤¤ #//
    priv static const int RADIUS;


    //# ¤¤¤¤¤¤¤¤¤¤¤¤¤ ATTRIBUTS ¤¤¤¤¤¤¤¤¤¤¤¤ #//
    priv int x, y;
    priv int speeds[2];  // ?? Still unsure ??
    priv Direc direc;


    //# ¤¤¤¤¤¤¤¤¤ GETTERS & SETTERS ¤¤¤¤¤¤¤¤ #//
    pub int getY()
    const noexcept {
      return self.y;
    }


    //# ¤¤¤¤¤¤¤¤¤¤¤¤¤¤ METHODS ¤¤¤¤¤¤¤¤¤¤¤¤¤ #//
    priv inline void drawBall(uint8_t r, uint8_t g, uint8_t b)
    const noexcept {
      /* Draw ball at current coordinates : (self.x , self.y) */

      screen.setColor(r,g,b);
      screen.fillCircle(self.x, self.y, RADIUS);
    }
    priv inline void eraseBall()
    const noexcept {
      /* Erase ball at current coordinates : (self.x , self.y) */

      self.drawBall(RGB_BLACK);
    }

    // -------------- DEBUG ------------- //
    //TODO : Debug ball
    /*
    pub inline void debug_drawBall(uint8_t r, uint8_t g, uint8_t b)
    const noexcept {
      self.erasePad();

      Serial.println("In draw");
      Serial.print("x : "); Serial.println(self.x);
      Serial.print("y : "); Serial.println(self.y);

      // Draw pad :
      drawBall(r,g,b);
    }
    */

    // -------------- SETUP ------------- //
    pub inline void spawn()
    noexcept {
      self.eraseBall();

      self.speeds[0] = 1;  // ?? x_speed est à revoir ??
      self.speeds[1] = 0;

      self.x = X_MID;
      self.y = Y_MID;

      self.drawBall(BALL_COLOUR);

      //TODO : Making choice random
      self.direc = Direc::Left;
    }

    // ------------- PLAYING ------------ //
    pub inline void getHit()
    noexcept {
      self.speeds[0] += 1;  // ?? valeur à revoir ??
    }

    priv inline int computeYSpeed(Pad &pad)
    const noexcept {
      /*
      Length of pad : 35px

      Part of pad : 5 px

      7 parts
      */

      int relative_y = self.y - pad.getYCenter();
      if (-2 <= relative_y && relative_y <= 2) {
        return 0;
      }
      
      int factor;
      if (relative_y > 2) {
        factor = -1;
      } else {
        factor = 1;
        relative_y *= -1;
      }

      int y_speed = 0;
      for (int i = 1; i <= (Pad::PAD_LENGTH / 5) / 2; ++i) {
        if (relative_y <= 2 + i * 5) {
          return factor * y_speed;
        }
        y_speed += 5;  // ?? valeur incertaine ??
      }
    }

    // TODO : Test if passed goal
    pub inline void move()
    noexcept {
      // Test if tap border :
      if (self.y == RADIUS || self.y == SCREEN_HEIGHT - RADIUS) {
        self.speeds[1] *= -1;
      }

      // Test if tap pad :
      if (
        self.x == Pad::PAD_WIDTH + RADIUS
        || self.x == SCREEN_WIDTH - (Pad::PAD_WIDTH + RADIUS)
      ) {
        switch (self.direc) {
          case Direc::Left : self.speeds[1] = self.computeYSpeed(player); break;
          case Direc::Right: self.speeds[1] = self.computeYSpeed(computer); break;
        }
      }

      //* Draw
      self.eraseBall();
      self.x += (int)self.direc * self.speeds[0];
      self.y += (int)self.direc * self.speeds[1];
      self.drawBall(BALL_COLOUR);
    }
  };
  const int Ball::RADIUS = 5;


  static Ball ball;
}



// ----------------------------------- SETUP -----------------------------------

void game_Pong_setup() {
  screen.InitLCD(LANDSCAPE);

  screen.fillScr(RGB_BLACK);

  // DEBUG ::
  Serial.println("In Setup");

  //ball.spawn();
  game_state = GameState::Playing;
}



// ------------------------------------ LOOP -----------------------------------

// DEBUG :: Test move functionnality
static bool player_up{ true }, computer_up{ false };
void game_Pong_loop() {
  Serial.println("Pong Loop");
  

  (player_up) ? player.moveUp(5) : player.moveDown(5);
  switch (player.getYTop()) {
    case Pad::TOP_LIMIT: player_up = false; break;
    case Pad::BOTTOM_LIMIT: player_up = true; break;
  }

  (computer_up) ? computer.moveUp(5) : computer.moveDown(5);
  switch (computer.getYTop()) {
    case Pad::TOP_LIMIT: computer_up = false; break;
    case Pad::BOTTOM_LIMIT: computer_up = true; break;
  }

  delay(100); //TODO : Test usefulness
}
