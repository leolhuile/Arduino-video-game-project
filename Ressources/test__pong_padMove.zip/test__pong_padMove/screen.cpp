#include "screen.h"

UTFT screen(SSD1289, 38, 39, 40, 41);

const int SCREEN_WIDTH  = 320; // <-- screen.getDisplayXSize()
const int SCREEN_HEIGHT = 240; // <-- screen.getDisplayYSize()

const int X_MID = SCREEN_WIDTH / 2;
const int Y_MID = SCREEN_HEIGHT / 2;

//#include "colors_.h"
void d_setColor(uint8_t r, uint8_t g, uint8_t b) {
  screen.setColor(r,g,b);
  delay(20);
}