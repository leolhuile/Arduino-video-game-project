#ifndef __OOP_MACROS__

  //To write more explicit oop easily :

  //* Access modifiers :
  #define priv private:
  #define prot protected:
  #define pub  public:

  //* Instance reference :
  #define self (*this)

  #define __OOP_MACROS__
#endif