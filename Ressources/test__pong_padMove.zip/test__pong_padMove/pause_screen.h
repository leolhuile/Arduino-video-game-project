#ifndef __PAUSE_SCREEN__
  #include "screen.h"
  #include "global_vars.h"

  void pause_screen_setup();
  void pause_screen_loop();

  #define __PAUSE_SCREEN__
#endif