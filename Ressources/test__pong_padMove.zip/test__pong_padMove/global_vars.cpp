#include "global_vars.h"

MainState main_state = MainState::Menu;
GameState game_state = GameState::Playing;

char b_message;