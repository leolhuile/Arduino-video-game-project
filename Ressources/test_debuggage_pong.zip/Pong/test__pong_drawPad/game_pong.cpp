#include "games.h"

// ----------------------------------- TOOLS -----------------------------------

// TODO : Removing those macros :
#define PAD_COLOUR RGB_GREEN
#define BALL_COLOUR RGB_GREEN

namespace {
  inline static void drawField(uint8_t r, uint8_t g, uint8_t b) { //TODO : Patch
    screen.setColor(r, g, b);

    // Borders :
    screen.drawHLine(0, 0, SCREEN_WIDTH);
    screen.drawHLine(0, SCREEN_HEIGHT, SCREEN_WIDTH);

    // Middle Line : // ?? Unsure as it looks like a border ??
    screen.drawVLine(X_MID, 0, SCREEN_HEIGHT);
  }



  /*************** PAD ***************/

  class Pad {
    //# ¤¤¤¤¤¤¤¤¤¤ CLASS ATTRIBUTS ¤¤¤¤¤¤¤¤¤ #//
    //Measures :
    pub static const int PAD_LENGTH;
    pub static const int PAD_WIDTH;
    //Limits :
    pub static const int TOP_LIMIT;
    pub static const int BOTTOM_LIMIT;


    //# ¤¤¤¤¤¤¤¤¤¤¤¤¤ ATTRIBUTS ¤¤¤¤¤¤¤¤¤¤¤¤ #//
    priv int x;
    priv int y; // y is the top of the pad not its middle


    //# ¤¤¤¤¤¤¤¤¤ GETTERS & SETTERS ¤¤¤¤¤¤¤¤ #//
    pub int getYTop()
    const noexcept {
      return self.y;
    }

    pub int getYCenter()
    const noexcept {
      return self.y + PAD_LENGTH / 2;
    }


    //# ¤¤¤¤¤¤¤¤¤¤¤¤¤¤ METHODS ¤¤¤¤¤¤¤¤¤¤¤¤¤ #//
    pub inline void debugPad(int i) // TODO : private
    const noexcept {
      self.erasePad();

      Serial.println("In draw");
      Serial.print("x : "); Serial.println(self.x);
      Serial.print("y : "); Serial.println(self.y);

      // Draw pad :
      if (i==0) screen.setColor(PAD_COLOUR);  // TODO : Choisir une couleur pour les pads
      else screen.setColor(RGB_WHITE);

      screen.fillRect(
        self.x, self.y,
        self.x + PAD_WIDTH, self.y + PAD_LENGTH
      );
    }


    priv inline void drawPad()
    const noexcept {
      /* Draw pad at current coordinates : (self.x , self.y) */

      // Draw pad :
      screen.setColor(PAD_COLOUR);  // TODO : Choisir une couleur pour les pads    
      screen.fillRect(
        self.x, self.y,
        self.x + PAD_WIDTH, self.y + PAD_LENGTH
      );
    }
    priv inline void erasePad()
    const noexcept {
      screen.setColor(RGB_BLACK);
      screen.fillRect(
        self.x, 0,
        self.x + PAD_WIDTH, SCREEN_HEIGHT
      );
    }

    // -------------- For SETUP ------------- //
    pub Pad() {} // To compile
    priv Pad(int x, int y) {
      self.x = x;
      self.y = y;
    }

    pub inline static Pad createPlayer() {
      return Pad(
        0,
        Y_MID - PAD_LENGTH / 2
      );
    }

    pub inline static Pad createComputer() {
      return Pad(
        SCREEN_WIDTH - PAD_WIDTH,
        Y_MID - PAD_LENGTH / 2
      );
    }

    // ------------- For PLAYING ------------ //
    pub inline void moveUp(int speed)
    noexcept {
      if (self.y == TOP_LIMIT) return;

      self.erasePad();
      self.y -= (speed <= self.y) ? speed : self.y;
      self.drawPad();
    }
    pub inline void moveDown(int speed)
    noexcept {
      if (self.y == BOTTOM_LIMIT) return;

      self.erasePad();
      const int dy = BOTTOM_LIMIT - self.y;
      self.y += (speed <= dy) ? speed : dy;
      self.drawPad();
    }
  };
  const int Pad::PAD_LENGTH = 35;
  const int Pad::PAD_WIDTH = 5;
  const int Pad::TOP_LIMIT = 0;
  const int Pad::BOTTOM_LIMIT = 205; // <-- SCREEN_HEIGHT - PAD_LENGTH


  static Pad player = Pad::createPlayer();
  static Pad computer = Pad::createComputer();


  /*************** BALL **************/

  class Ball {
    enum class Direc { Right = 1, Left = -1 };

    //# ¤¤¤¤¤¤¤¤¤¤ CLASS ATTRIBUTS ¤¤¤¤¤¤¤¤¤ #//
    priv static const int RADIUS;


    //# ¤¤¤¤¤¤¤¤¤¤¤¤¤ ATTRIBUTS ¤¤¤¤¤¤¤¤¤¤¤¤ #//
    priv int x, y;
    priv int speeds[2];  // ?? Still unsure ??
    priv Direc direc;


    //# ¤¤¤¤¤¤¤¤¤ GETTERS & SETTERS ¤¤¤¤¤¤¤¤ #//
    pub int getY()
    const noexcept {
      return self.y;
    }


    //# ¤¤¤¤¤¤¤¤¤¤¤¤¤¤ METHODS ¤¤¤¤¤¤¤¤¤¤¤¤¤ #//
    priv inline void drawBall()
    const noexcept {
      /* Draw pad at current coordinates : (self.x , self.y) */

      screen.setColor(BALL_COLOUR);
      screen.fillCircle(self.x, self.y, RADIUS);
    }
    priv inline void eraseBall()
    const noexcept {
      /* Draw pad at current coordinates : (self.x , self.y) */

      screen.setColor(BALL_COLOUR);
      screen.fillCircle(self.x, self.y, RADIUS);
    }

    // -------------- For SETUP ------------- //
    pub inline void spawn()
    noexcept {
      self.eraseBall();

      self.speeds[0] = 1;  // ?? x_speed est à revoir ??
      self.speeds[1] = 0;

      self.x = X_MID;
      self.y = Y_MID;

      self.drawBall();

      //TODO : Making choice random
      self.direc = Direc::Left;
    }

    // ------------- For PLAYING ------------ //
    pub inline void getHit()
    noexcept {
      self.speeds[0] += 1;  // ?? valeur à revoir ??
    }

    priv inline int computeYSpeed(Pad pad)
    const noexcept {
      /*
      Length of pad : 35px

      Part of pad : 5 px

      7 parts
      */

      int relative_y = self.y - pad.getYCenter();
      if (-2 <= relative_y && relative_y <= 2) {
        return 0;
      }
      
      int factor;
      if (relative_y > 2) {
        factor = -1;
      } else {
        factor = 1;
        relative_y *= -1;
      }

      int y_speed = 0;
      for (int i = 1; i <= (Pad::PAD_LENGTH / 5) / 2; ++i) {
        if (relative_y <= 2 + i * 5) {
          return factor * y_speed;
        }
        y_speed += 5;  // ?? valeur incertaine ??
      }
    }

    // TODO : Test if passed goal
    pub inline void move()
    noexcept {
      // Test if tap border :
      if (self.y == RADIUS || self.y == SCREEN_HEIGHT - RADIUS) {
        self.speeds[1] *= -1;
      }

      // Test if tap pad :
      if (
        self.x == Pad::PAD_WIDTH + RADIUS
        || self.x == SCREEN_WIDTH - (Pad::PAD_WIDTH + RADIUS)
      ) {
        Pad pad;
        switch (self.direc) {
          case Direc::Left: pad = player; break;
          case Direc::Right: pad = computer; break;
        }
        self.speeds[1] = self.computeYSpeed(pad);
      }

      //* Draw
      self.eraseBall();
      self.x += (int)self.direc * self.speeds[0];
      self.y += (int)self.direc * self.speeds[1];
      self.drawBall();
    }
  };
  const int Ball::RADIUS = 5;


  static Ball ball;
}


// ----------------------------------- SETUP -----------------------------------

void game_Pong_setup() {
  screen.InitLCD(LANDSCAPE); // A retirer si c pas dans le 1er setup (normalement le 1er est 'menu_setup')

  screen.fillScr(RGB_BLACK);
  drawField(RGB_WHITE);

  // DEBUG ::
  Serial.println("In Setup");

  //ball.spawn();
  game_state = GameState::Playing;
}


// ------------------------------------ LOOP -----------------------------------

void game_Pong_loop() {
  player.debugPad(0);
  delay(1000);

  computer.debugPad(1);
  delay(1000);
}