#ifndef __MENU__
  #include "screen.h"

  void menu_setup();
  void menu_loop();

  #define __MENU__
#endif